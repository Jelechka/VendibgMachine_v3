﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для UpdateDrinks.xaml
    /// </summary>
    public partial class UpdateDrinks : Page
    {
        DrinksInMach dim = new DrinksInMach();

        bool imageUpdate = false;
        public UpdateDrinks()
        {
            InitializeComponent();

            dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.DrinksId == ViewDrinks.idDrink).First();

            tbCost.Text = dim.Cost.ToString();
            tbCount.Text = dim.Count.ToString();

            byte[] imageData = dim.Image;
            var image = new BitmapImage();
            using (var mem = new MemoryStream(imageData))
            {
                mem.Position = 0;
                image.BeginInit();
                image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = null;
                image.StreamSource = mem;
                image.EndInit();
            }
            image.Freeze();
            img.Source = image;

            brImage.BorderBrush = Brushes.Transparent;
        }

        public string GetPath()
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true)
            {
                return dialog.FileName;
            }
            return null;
        }

        public byte[] getPNGFromImageControl(BitmapImage imageC)
        {
            MemoryStream memStream = new MemoryStream();
            PngBitmapEncoder encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(imageC));
            encoder.Save(memStream);
            return memStream.ToArray();
        }

        private void brImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            string path = GetPath();
            if (path == null) return;
            var pic = File.ReadAllBytes(path);
            var image = new BitmapImage();
            using (var mem = new MemoryStream(pic))
            {
                mem.Position = 0;
                image.BeginInit();
                image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = null;
                image.StreamSource = mem;
                image.EndInit();
            }
            image.Freeze();
            img.Source = image;

            imageUpdate = true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Save();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Drinks drink = ConnectHelper.entObj.Drinks.FirstOrDefault(v => v.Id == dim.DrinksId);
            VendMachineDrinks vmDrinks = ConnectHelper.entObj.VendMachineDrinks.FirstOrDefault(x => x.DrinksId == dim.DrinksId);
            if (drink == null) MessageBox.Show("Нечего удалять!", "Важно", MessageBoxButton.OK);
            else
            {
                if (MessageBox.Show("Выьраный напиток < " + drink.Name + " > будет удален!", "Удаление напитка!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    ConnectHelper.entObj.VendMachineDrinks.Remove(vmDrinks);
                    ConnectHelper.entObj.SaveChanges();

                    ConnectHelper.entObj.Drinks.Remove(drink);
                    ConnectHelper.entObj.SaveChanges();

                    MainWindow.countInStart.Remove(dim);

                    FrameApp.frmObj.GoBack();
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if(btnSave.IsEnabled == false)
            {
                FrameApp.frmObj.GoBack();
            }
            else if (imageUpdate == true)
            {
                if (MessageBox.Show($"Изображение было изменено! Сохранить перед выходом?", "Внимение!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Save();
                    FrameApp.frmObj.GoBack();
                }
                else
                {
                    FrameApp.frmObj.GoBack();
                }
            }
            else if (tbCost.Text == dim.Cost.ToString() && tbCount.Text == dim.Count.ToString())
            {
                FrameApp.frmObj.GoBack();
            }
            else
            {
                if (MessageBox.Show($"Введенные данные не будут сохранены! Сохраните перед выходом?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Save();
                    FrameApp.frmObj.GoBack();
                }
                else
                {
                    FrameApp.frmObj.GoBack();
                }
            } 
        }

        private void Save()
        {
            if (tbCount.Text == "" && tbCost.Text == "")
            {
                labError.Content = "Введите данные и попробуйте снова!";
            }
            else if (tbCost.Text == "" || !decimal.TryParse(tbCount.Text, out _))
            {
                labError.Content = "Укажите цену напитка!";
            }
            else if (tbCount.Text == "" || !int.TryParse(tbCount.Text, out _))
            {
                labError.Content = "Укажите количество напитка!";
            }
            else
            {
                labError.Content = "";
                try
                {
                    VendMachineDrinks vmd = ConnectHelper.entObj.VendMachineDrinks.Where(v => v.DrinksId == dim.DrinksId && v.VendMachId == 1).First();
                    Drinks drink = ConnectHelper.entObj.Drinks.Where(v => v.Id == dim.DrinksId).First();

                    vmd.Count = int.Parse(tbCount.Text);
                    drink.Image = getPNGFromImageControl(img.Source as BitmapImage);
                    drink.Cost = decimal.Parse(tbCost.Text);

                    ConnectHelper.entObj.SaveChanges();

                    labError.Content = "Данные успешно сохранены!";
                    btnSave.IsEnabled = false;
                    imageUpdate = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message.ToString(), "Важно", MessageBoxButton.OK);
                }
            }
        }

        private void tbCost_TextChanged(object sender, TextChangedEventArgs e)
        {
            btnSave.IsEnabled = true;
        }

        private void tbCount_TextChanged(object sender, TextChangedEventArgs e)
        {
            btnSave.IsEnabled = true;
        }
    }
}
