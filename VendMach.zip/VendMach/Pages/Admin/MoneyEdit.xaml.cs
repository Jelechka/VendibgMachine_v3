﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для MoneyEdit.xaml
    /// </summary>
    public partial class MoneyEdit : Page
    {
        public MoneyEdit()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            tbRub1.Text = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().Count.ToString();
            tbRub2.Text = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().Count.ToString();
            tbRub5.Text = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().Count.ToString();
            tbRub10.Text = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().Count.ToString();

            if (ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().IsActive == 0) chbIsActive1.IsChecked = false;
            if (ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().IsActive == 0) chbIsActive2.IsChecked = false;
            if (ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().IsActive == 0) chbIsActive5.IsChecked = false;
            if (ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().IsActive == 0) chbIsActive10.IsChecked = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().Count = int.Parse(tbRub1.Text);
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().Count = int.Parse(tbRub2.Text);
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().Count = int.Parse(tbRub5.Text);
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().Count = int.Parse(tbRub10.Text);

            if (chbIsActive1.IsChecked==true)  ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().IsActive = 1;
            else ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().IsActive = 0;

            if (chbIsActive2.IsChecked == true) ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().IsActive = 1;
            else ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().IsActive = 0;

            if (chbIsActive5.IsChecked == true) ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().IsActive = 1;
            else ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().IsActive = 0;

            if (chbIsActive10.IsChecked == true) ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().IsActive = 1;
            else ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().IsActive = 0;

            ConnectHelper.entObj.SaveChanges();
        }

        private void btnMinus1_Click(object sender, RoutedEventArgs e)
        {
            tbRub1.Text = (int.Parse(tbRub1.Text) - 1).ToString();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            tbRub1.Text = (int.Parse(tbRub1.Text) + 1).ToString();
        }

        private void btnMinus2_Click(object sender, RoutedEventArgs e)
        {
            tbRub2.Text = (int.Parse(tbRub2.Text) - 1).ToString();
        }

        private void btnPlus2_Click(object sender, RoutedEventArgs e)
        {
            tbRub2.Text = (int.Parse(tbRub2.Text) + 1).ToString();
        }

        private void btnMinus5_Click(object sender, RoutedEventArgs e)
        {
            tbRub5.Text = (int.Parse(tbRub5.Text) - 1).ToString();
        }

        private void btnPlus5_Click(object sender, RoutedEventArgs e)
        {
            tbRub5.Text = (int.Parse(tbRub5.Text) + 1).ToString();
        }

        private void btnMinus10_Click(object sender, RoutedEventArgs e)
        {
            tbRub10.Text = (int.Parse(tbRub10.Text) - 1).ToString();
        }

        private void btnPlus10_Click(object sender, RoutedEventArgs e)
        {
            tbRub10.Text = (int.Parse(tbRub10.Text) + 1).ToString();
        }
    }
}
