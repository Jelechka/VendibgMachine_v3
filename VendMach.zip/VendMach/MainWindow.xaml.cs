﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using VendMach.Pages;
using VendMach.Scripts;

namespace VendMach
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // сохранение начальных данных о напитках
        public static List<DrinksInMach> countInStart { get; set; }
        public MainWindow()
        {
            InitializeComponent();

            ConnectHelper.entObj = new VendMachEntities();
            countInStart = new List<DrinksInMach>();
            //
            foreach (DrinksInMach dim in ConnectHelper.entObj.DrinksInMach)
            {
                countInStart.Add(dim);
            }
            FrameApp.frmObj = frmMain;
            frmMain.Navigate(new UserUI());
        }

        //Метод сворачивания окна (приложения)
        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        //Метод разворачивания окна на весь экран и возварщения его в нормальное состояние 
        private void btnMax_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState != WindowState.Maximized) WindowState = WindowState.Maximized;
            else WindowState = WindowState.Normal;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //Метод перетаскиваня окна по экрану
        private void brDrop_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }
    }
}
